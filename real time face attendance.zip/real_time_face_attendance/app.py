"""
app.py — Face Attendance System  v3.0
======================================
NEW in this version:
  📊 Analytics tab  — charts, attendance %, monthly report, low-attendance alerts
  📅 Schedule tab   — subjects, timetable, holidays, session timer
  🤖 AI Assistant   — smart chatbot with attendance knowledge
  + all previous features

Run: python app.py
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, ttk, colorchooser
import threading, subprocess, sys, os, csv, glob
import pickle, queue, json, re, webbrowser, math
from datetime import datetime, timedelta
from collections import defaultdict
from PIL import Image, ImageTk
import cv2, numpy as np

# ── EXE-safe paths ─────────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def p(path): return os.path.join(BASE_DIR, path)

CASCADE_PATH      = p("haarcascade_frontalface_default.xml")
MODEL_PATH        = p("TrainingImageLabel/trainer.yml")
NAMES_PATH        = p("TrainingImageLabel/names.pkl")
TRAINING_DIR      = p("TrainingImage")
ATTENDANCE_DIR    = p("Attendance")
SCHEDULE_FILE     = p("schedule.json")
CONFIDENCE_THRESH = 70

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

BG      = "#0d1117"; SURFACE = "#161b22"; SURF2 = "#21262d"
BORDER  = "#30363d"; TEXT    = "#e6edf3"; MUTED  = "#8b949e"
GREEN   = "#3fb950"; RED     = "#f85149"; BLUE   = "#58a6ff"
YELLOW  = "#e3b341"; ACCENT  = "#1f6feb"; PURPLE = "#8957e5"
ORANGE  = "#f0883e"; TEAL    = "#2dd4bf"


# ═══════════════════════════════════════════════════════════════════════════════
#  SCHEDULE MANAGER
# ═══════════════════════════════════════════════════════════════════════════════

class ScheduleManager:
    """Manages subjects, timetable slots and holidays via JSON."""

    DEFAULT = {
        "subjects": [],          # [{id, name, color}]
        "slots": [],             # [{day, start, end, subject_id}]
        "holidays": [],          # ["2026-03-25", ...]
        "active_subject": None,  # currently selected subject id
        "session_minutes": 60,   # default session duration
    }

    def __init__(self):
        self.data = self._load()

    def _load(self):
        if os.path.exists(SCHEDULE_FILE):
            try:
                with open(SCHEDULE_FILE) as f:
                    d = json.load(f)
                    # fill missing keys
                    for k, v in self.DEFAULT.items():
                        d.setdefault(k, v)
                    return d
            except Exception:
                pass
        return dict(self.DEFAULT)

    def save(self):
        with open(SCHEDULE_FILE, 'w') as f:
            json.dump(self.data, f, indent=2)

    def add_subject(self, name, color="#58a6ff"):
        sid = f"s{int(datetime.now().timestamp()*1000)}"
        self.data["subjects"].append({"id": sid, "name": name, "color": color})
        self.save()
        return sid

    def delete_subject(self, sid):
        self.data["subjects"] = [s for s in self.data["subjects"] if s["id"] != sid]
        self.data["slots"]    = [sl for sl in self.data["slots"] if sl["subject_id"] != sid]
        if self.data["active_subject"] == sid:
            self.data["active_subject"] = None
        self.save()

    def add_slot(self, day, start, end, subject_id):
        self.data["slots"].append({"day": day, "start": start,
                                    "end": end, "subject_id": subject_id})
        self.save()

    def delete_slot(self, idx):
        if 0 <= idx < len(self.data["slots"]):
            self.data["slots"].pop(idx)
            self.save()

    def add_holiday(self, date_str):
        if date_str not in self.data["holidays"]:
            self.data["holidays"].append(date_str)
            self.save()

    def remove_holiday(self, date_str):
        self.data["holidays"] = [d for d in self.data["holidays"] if d != date_str]
        self.save()

    def is_holiday(self, date_str=None):
        if date_str is None:
            date_str = datetime.now().strftime("%Y-%m-%d")
        return date_str in self.data["holidays"]

    def current_slot(self):
        """Return (subject_name, end_time) if a class is scheduled right now."""
        now  = datetime.now()
        day  = now.strftime("%A")   # Monday, Tuesday …
        time = now.strftime("%H:%M")
        subj_map = {s["id"]: s for s in self.data["subjects"]}
        for slot in self.data["slots"]:
            if slot["day"] == day and slot["start"] <= time <= slot["end"]:
                subj = subj_map.get(slot["subject_id"])
                if subj:
                    return subj["name"], slot["end"]
        return None, None

    def get_attendance_file(self, subject_id=None):
        """Return path for today's attendance CSV, optionally per subject."""
        os.makedirs(ATTENDANCE_DIR, exist_ok=True)
        date = datetime.now().strftime("%Y-%m-%d")
        subj_map = {s["id"]: s["name"] for s in self.data["subjects"]}
        if subject_id and subject_id in subj_map:
            safe = re.sub(r'[^\w]', '_', subj_map[subject_id])
            fname = f"Attendance_{date}_{safe}.csv"
        else:
            fname = f"Attendance_{date}.csv"
        path = os.path.join(ATTENDANCE_DIR, fname)
        if not os.path.exists(path):
            with open(path, 'w', newline='') as f:
                csv.writer(f).writerow(["ID","Name","Subject","Date","Time","Status"])
        return path


# ═══════════════════════════════════════════════════════════════════════════════
#  ANALYTICS ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class AnalyticsEngine:
    """Reads all CSV files and computes analytics."""

    def load_all(self):
        data = {}
        for f in glob.glob(os.path.join(ATTENDANCE_DIR, "*.csv")):
            fn = os.path.basename(f)
            try:
                rows = []
                with open(f) as fh:
                    for row in csv.DictReader(fh):
                        rows.append(row)
                data[fn] = rows
            except Exception:
                continue
        return data

    def student_stats(self):
        """
        Returns {name: {"present": N, "total_sessions": N, "pct": float,
                         "dates": [...]}}
        """
        all_data  = self.load_all()
        sessions  = len(all_data)
        counts    = defaultdict(lambda: {"present": 0, "dates": set()})

        for fname, rows in all_data.items():
            seen_today = set()
            for row in rows:
                name = row.get("Name","").strip()
                date = row.get("Date","")
                if name and name not in seen_today:
                    counts[name]["present"] += 1
                    counts[name]["dates"].add(date)
                    seen_today.add(name)

        result = {}
        for name, info in counts.items():
            pct = round(info["present"] / sessions * 100, 1) if sessions else 0
            result[name] = {
                "present":        info["present"],
                "total_sessions": sessions,
                "pct":            pct,
                "dates":          sorted(info["dates"]),
            }
        return result

    def daily_totals(self):
        """Returns {date: count} for all days."""
        all_data = self.load_all()
        totals   = defaultdict(int)
        for fname, rows in all_data.items():
            seen = set()
            for row in rows:
                name = row.get("Name","").strip()
                date = row.get("Date","") or fname[:10]
                if name and name not in seen:
                    totals[date] += 1
                    seen.add(name)
        return dict(totals)

    def subject_stats(self):
        """Returns {subject: {date: count}} from files with subject in name."""
        stats = defaultdict(lambda: defaultdict(int))
        for f in glob.glob(os.path.join(ATTENDANCE_DIR, "*.csv")):
            fn = os.path.basename(f)
            parts = fn.replace(".csv","").split("_")
            subj = "_".join(parts[2:]) if len(parts) > 2 else "General"
            try:
                with open(f) as fh:
                    seen = set()
                    for row in csv.DictReader(fh):
                        name = row.get("Name","").strip()
                        date = row.get("Date","")
                        if name and name not in seen:
                            stats[subj][date] += 1
                            seen.add(name)
            except Exception:
                continue
        return {k: dict(v) for k,v in stats.items()}

    def today_str(self):
        return datetime.now().strftime("%Y-%m-%d")

    def all_students(self):
        if os.path.exists(NAMES_PATH):
            with open(NAMES_PATH,'rb') as f:
                return pickle.load(f)
        return {}


# ═══════════════════════════════════════════════════════════════════════════════
#  SMART CHATBOT
# ═══════════════════════════════════════════════════════════════════════════════

class SmartBot:
    def __init__(self, engine: AnalyticsEngine, app_ref):
        self.engine  = engine
        self.app_ref = app_ref

    def _s(self):
        stats    = self.engine.student_stats()
        all_stud = self.engine.all_students()
        today    = self.engine.today_str()
        today_file = f"Attendance_{today}.csv"
        all_data = self.engine.load_all()
        today_rows = all_data.get(today_file, [])
        present_today = list({r.get("Name","").strip() for r in today_rows if r.get("Name","").strip()})
        absent_today  = [n for n in all_stud.values() if n not in present_today]
        return {"stats": stats, "present_today": present_today,
                "absent_today": absent_today, "registered": list(all_stud.values()),
                "total_sessions": len(all_data), "today": today}

    def respond(self, msg):
        m = msg.lower().strip()
        s = self._s()

        # Commands
        cmd_map = {
            ("start attendance","open camera","mark attendance","begin attendance"):
                ("Attendance", self.app_ref._start_cam, "📷 Opening camera!"),
            ("stop camera","stop attendance"):
                (None, self.app_ref._stop_cam, "⏹ Camera stopped."),
            ("export excel","download excel","save excel"):
                (None, self.app_ref._export_excel, "⬇ Exporting to Excel..."),
            ("train model","retrain","update model"):
                ("Train", self.app_ref._start_train, "🧠 Starting training!"),
            ("register student","add student","new student"):
                ("Register", None, "📸 Opened Register tab!"),
            ("open dashboard","web dashboard"):
                (None, self.app_ref._open_web, "🌐 Opening dashboard!"),
            ("show analytics","view analytics","open analytics"):
                ("Analytics", None, "📊 Opened Analytics tab!"),
            ("schedule","timetable","open schedule"):
                ("Schedule", None, "📅 Opened Schedule tab!"),
        }
        for keys, (nav, fn, reply) in cmd_map.items():
            if any(k in m for k in keys):
                if nav: self.app_ref.after(0, lambda n=nav: self.app_ref._nav(n))
                if fn:  self.app_ref.after(300, fn)
                return reply

        # Attendance queries
        if any(x in m for x in ["who came","present today","today attendance","who attended"]):
            if s["present_today"]:
                return f"✅ {len(s['present_today'])} present today:\n\n" + \
                       "\n".join(f"  • {n}" for n in s["present_today"])
            return "📭 Nobody marked yet today. Start the camera!"

        if any(x in m for x in ["absent","who missed","not present"]):
            if s["absent_today"]:
                return f"❌ {len(s['absent_today'])} absent today:\n\n" + \
                       "\n".join(f"  • {n}" for n in s["absent_today"])
            return "🎉 All students present today!"

        if any(x in m for x in ["how many today","count today","total today"]):
            t = len(s["registered"]); p2 = len(s["present_today"])
            pct = int(p2/t*100) if t else 0
            return f"📊 Today: {p2}/{t} present ({pct}%)"

        if any(x in m for x in ["low attendance","below 75","struggling","at risk"]):
            low = [(n,d["pct"]) for n,d in s["stats"].items() if d["pct"] < 75]
            if low:
                lines = "\n".join(f"  ⚠ {n}: {pct}%" for n,pct in sorted(low,key=lambda x:x[1]))
                return f"⚠ Students below 75%:\n\n{lines}"
            return "✅ All students are above 75% attendance!"

        if any(x in m for x in ["best attendance","top student","highest"]):
            if s["stats"]:
                best = max(s["stats"], key=lambda n: s["stats"][n]["pct"])
                return f"🏆 Best: {best} ({s['stats'][best]['pct']}%)"

        if any(x in m for x in ["worst","lowest","least"]):
            if s["stats"]:
                worst = min(s["stats"], key=lambda n: s["stats"][n]["pct"])
                return f"⚠ Lowest: {worst} ({s['stats'][worst]['pct']}%)"

        # Specific student
        for name in s["registered"]:
            if name.lower() in m:
                d = s["stats"].get(name)
                if d:
                    status = "✅ present" if name in s["present_today"] else "❌ absent"
                    bar = "█" * int(d["pct"]//10) + "░" * (10 - int(d["pct"]//10))
                    return (f"👤 {name}\n\n"
                            f"  Today      : {status}\n"
                            f"  Sessions   : {d['present']}/{d['total_sessions']}\n"
                            f"  Attendance : {d['pct']}%\n"
                            f"  [{bar}]")

        if any(x in m for x in ["list students","all students","registered"]):
            if s["registered"]:
                return "👥 Registered students:\n\n" + \
                       "\n".join(f"  • {n}" for n in sorted(s["registered"]))
            return "No students registered yet."

        if any(x in m for x in ["help","what can","commands"]):
            return ("🤖 I can help with:\n\n"
                    "📊 QUESTIONS:\n"
                    "  • Who came today?\n"
                    "  • Who is absent?\n"
                    "  • Show [name]'s attendance\n"
                    "  • Who has low attendance?\n"
                    "  • Best / worst attendance\n\n"
                    "🎮 COMMANDS:\n"
                    "  • Start attendance\n"
                    "  • Export Excel\n"
                    "  • Train model\n"
                    "  • Open analytics\n"
                    "  • Open schedule")

        if any(x in m for x in ["hi","hello","hey","hlo"]):
            hour = datetime.now().hour
            g = "Good morning" if hour<12 else "Good afternoon" if hour<17 else "Good evening"
            return f"{g}! 👋 {len(s['present_today'])} student(s) marked today.\nAsk me anything or say 'help'!"

        if any(x in m for x in ["date","today's date"]):
            return f"📅 {datetime.now().strftime('%A, %d %B %Y')}"

        return ("🤔 Not sure about that. Try:\n"
                "  • 'Who came today?'\n"
                "  • 'Show Rahul's attendance'\n"
                "  • 'Who has low attendance?'\n"
                "  • 'Open analytics'")


class OllamaBot:
    MODEL = "llama3"

    def __init__(self, engine, app_ref):
        self.engine = engine; self.app_ref = app_ref; self.history = []

    @staticmethod
    def is_available():
        try:
            import urllib.request
            urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2)
            return True
        except Exception:
            return False

    def _system(self):
        stats = self.engine.student_stats()
        lines = "\n".join(f"  {n}: {d['pct']}% ({d['present']}/{d['total_sessions']})"
                           for n,d in stats.items()) or "  No data"
        return (f"You are an AI assistant for a Face Attendance System.\n"
                f"Today: {self.engine.today_str()}\n"
                f"Student attendance:\n{lines}\n\n"
                f"Commands you can trigger by including these tags:\n"
                f"[CMD:start_attendance] [CMD:stop_camera] [CMD:export_excel]\n"
                f"[CMD:train_model] [CMD:open_analytics] [CMD:open_schedule]\n"
                f"Be helpful, concise, and friendly.")

    def _exec(self, reply):
        cmd_map = {
            "start_attendance": (lambda: (self.app_ref._nav("Attendance"), self.app_ref.after(300, self.app_ref._start_cam))),
            "stop_camera":      self.app_ref._stop_cam,
            "export_excel":     self.app_ref._export_excel,
            "train_model":      (lambda: (self.app_ref._nav("Train"), self.app_ref.after(300, self.app_ref._start_train))),
            "open_analytics":   lambda: self.app_ref._nav("Analytics"),
            "open_schedule":    lambda: self.app_ref._nav("Schedule"),
        }
        for cmd in re.findall(r'\[CMD:(\w+)\]', reply):
            fn = cmd_map.get(cmd)
            if fn: self.app_ref.after(0, fn)
        return re.sub(r'\[CMD:\w+\]','',reply).strip()

    def chat(self, msg):
        import urllib.request, json as _j
        self.history.append({"role":"user","content":msg})
        payload = {"model": self.MODEL, "stream": False,
                   "messages": [{"role":"system","content":self._system()}] + self.history[-12:]}
        req = urllib.request.Request(
            "http://localhost:11434/api/chat",
            data=_j.dumps(payload).encode(),
            headers={"Content-Type":"application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=60) as r:
            reply = _j.loads(r.read())["message"]["content"]
        reply = self._exec(reply)
        self.history.append({"role":"assistant","content":reply})
        return reply


# ═══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def load_model():
    if not os.path.exists(MODEL_PATH) or not os.path.exists(NAMES_PATH):
        return None, None
    rec = cv2.face.LBPHFaceRecognizer_create(); rec.read(MODEL_PATH)
    with open(NAMES_PATH,'rb') as f: return rec, pickle.load(f)

def mark_attendance(sid, name, subj, att_file, marked_set):
    if sid in marked_set: return False
    marked_set.add(sid)
    now = datetime.now()
    with open(att_file,'a',newline='') as f:
        csv.writer(f).writerow([sid, name, subj,
                                 now.strftime("%Y-%m-%d"),
                                 now.strftime("%H:%M:%S"), "Present"])
    return True

def draw_corner_box(img,x,y,w,h,color,length=22,thick=3):
    for pts in [((x,y),(x+length,y)),((x,y),(x,y+length)),
                ((x+w,y),(x+w-length,y)),((x+w,y),(x+w,y+length)),
                ((x,y+h),(x+length,y+h)),((x,y+h),(x,y+h-length)),
                ((x+w,y+h),(x+w-length,y+h)),((x+w,y+h),(x+w,y+h-length))]:
        cv2.line(img,pts[0],pts[1],color,thick)

def put_label(img,text,x,y,color,bg):
    font=cv2.FONT_HERSHEY_SIMPLEX
    (tw,th),bl=cv2.getTextSize(text,font,0.55,1)
    cv2.rectangle(img,(x-4,y-th-4),(x+tw+4,y+bl+4),bg,-1)
    cv2.putText(img,text,(x,y),font,0.55,color,1,cv2.LINE_AA)


# ═══════════════════════════════════════════════════════════════════════════════
#  CANVAS CHART HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def draw_bar_chart(canvas, data: dict, width, height,
                   threshold=75, title="Attendance %"):
    """Draw a bar chart on a tk.Canvas. data = {name: pct}"""
    canvas.delete("all")
    if not data:
        canvas.create_text(width//2, height//2, text="No data yet",
                           fill=MUTED, font=("Segoe UI",13))
        return

    pad_l=60; pad_r=20; pad_t=40; pad_b=60
    chart_w = width  - pad_l - pad_r
    chart_h = height - pad_t - pad_b
    n       = len(data)
    bar_w   = max(20, min(60, chart_w // n - 8))
    gap     = (chart_w - bar_w * n) // (n + 1)

    # Background
    canvas.create_rectangle(0,0,width,height, fill=SURFACE, outline="")
    # Title
    canvas.create_text(width//2, pad_t//2, text=title,
                       fill=TEXT, font=("Segoe UI",12,"bold"))
    # Y axis
    for pct in [0,25,50,75,100]:
        y = pad_t + chart_h - int(pct/100 * chart_h)
        canvas.create_line(pad_l-5, y, pad_l+chart_w, y,
                           fill=BORDER, dash=(4,4))
        canvas.create_text(pad_l-8, y, text=f"{pct}%",
                           fill=MUTED, font=("Segoe UI",9), anchor="e")
    # Threshold line
    thresh_y = pad_t + chart_h - int(threshold/100 * chart_h)
    canvas.create_line(pad_l, thresh_y, pad_l+chart_w, thresh_y,
                       fill=YELLOW, dash=(6,3), width=1.5)
    canvas.create_text(pad_l+chart_w+2, thresh_y,
                       text=f"{threshold}%", fill=YELLOW,
                       font=("Segoe UI",8), anchor="w")

    # Bars
    items = list(data.items())
    for i,(name,pct) in enumerate(items):
        x = pad_l + gap + i*(bar_w+gap)
        bar_h_px = int(pct/100 * chart_h)
        y_top = pad_t + chart_h - bar_h_px
        color = GREEN if pct >= threshold else RED if pct < 50 else YELLOW

        # Bar
        canvas.create_rectangle(x, y_top, x+bar_w, pad_t+chart_h,
                                 fill=color, outline="", tags=f"bar{i}")
        # Value label on top
        canvas.create_text(x+bar_w//2, y_top-6, text=f"{pct:.0f}%",
                            fill=color, font=("Segoe UI",9,"bold"))
        # Name below
        short = name[:8]+"…" if len(name)>9 else name
        canvas.create_text(x+bar_w//2, pad_t+chart_h+12,
                            text=short, fill=TEXT,
                            font=("Segoe UI",9), angle=30 if n>6 else 0)

    # X axis line
    canvas.create_line(pad_l, pad_t+chart_h, pad_l+chart_w, pad_t+chart_h,
                       fill=BORDER, width=1)
    canvas.create_line(pad_l, pad_t, pad_l, pad_t+chart_h,
                       fill=BORDER, width=1)


def draw_line_chart(canvas, data: dict, width, height, title="Daily Attendance"):
    """data = {date_str: count}"""
    canvas.delete("all")
    if not data:
        canvas.create_text(width//2, height//2, text="No data yet",
                           fill=MUTED, font=("Segoe UI",13))
        return

    pad_l=50; pad_r=20; pad_t=40; pad_b=50
    chart_w = width  - pad_l - pad_r
    chart_h = height - pad_t - pad_b

    canvas.create_rectangle(0,0,width,height, fill=SURFACE, outline="")
    canvas.create_text(width//2, pad_t//2, text=title,
                       fill=TEXT, font=("Segoe UI",12,"bold"))

    sorted_dates = sorted(data.keys())[-30:]   # last 30 days
    counts       = [data[d] for d in sorted_dates]
    max_c        = max(counts) if counts else 1
    n            = len(sorted_dates)

    # Y gridlines
    for i in range(5):
        val = int(max_c * i / 4)
        y   = pad_t + chart_h - int(val/max_c * chart_h)
        canvas.create_line(pad_l, y, pad_l+chart_w, y, fill=BORDER, dash=(4,4))
        canvas.create_text(pad_l-6, y, text=str(val), fill=MUTED,
                           font=("Segoe UI",9), anchor="e")

    # Line + dots
    pts = []
    for i,(d,c) in enumerate(zip(sorted_dates, counts)):
        x = pad_l + int(i/(n-1 if n>1 else 1) * chart_w)
        y = pad_t + chart_h - int(c/max_c * chart_h)
        pts.extend([x,y])
        canvas.create_oval(x-4,y-4,x+4,y+4, fill=BLUE, outline="")

    if len(pts) >= 4:
        canvas.create_line(*pts, fill=BLUE, width=2, smooth=True)

    # X labels (show ~6)
    step = max(1, n//6)
    for i in range(0, n, step):
        x = pad_l + int(i/(n-1 if n>1 else 1) * chart_w)
        canvas.create_text(x, pad_t+chart_h+14,
                           text=sorted_dates[i][5:],  # MM-DD
                           fill=MUTED, font=("Segoe UI",8))

    canvas.create_line(pad_l, pad_t+chart_h, pad_l+chart_w, pad_t+chart_h,
                       fill=BORDER); 
    canvas.create_line(pad_l, pad_t, pad_l, pad_t+chart_h, fill=BORDER)


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN APP
# ═══════════════════════════════════════════════════════════════════════════════

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Face Attendance System")
        self.geometry("1220x760")
        self.minsize(1000,660)
        self.configure(fg_color=BG)

        self.camera_running = False
        self.cap            = None
        self.marked_today   = set()
        self.dashboard_proc = None
        self._file_label_map = {}
        self._all_records    = []
        self.session_timer   = None
        self.session_seconds = [0]

        self.sched   = ScheduleManager()
        self.analytics = AnalyticsEngine()
        self.smart_bot = SmartBot(self.analytics, self)
        self.ollama_bot = None
        self._chat_mode = "smart"
        self._check_ollama()

        self._build_layout()
        self._nav("Dashboard")

    def _check_ollama(self):
        def check():
            if OllamaBot.is_available():
                self.ollama_bot = OllamaBot(self.analytics, self)
                self._chat_mode = "ollama"
        threading.Thread(target=check, daemon=True).start()

    # ── LAYOUT ────────────────────────────────────────────────────────────────

    def _build_layout(self):
        self.sidebar = ctk.CTkFrame(self, width=215, fg_color=SURFACE, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        ctk.CTkLabel(self.sidebar, text="👁‍🗨", font=("Segoe UI Emoji",28)).pack(pady=(20,2))
        ctk.CTkLabel(self.sidebar, text="Face Attendance",
                     font=("Segoe UI",13,"bold"), text_color=TEXT).pack()
        ctk.CTkFrame(self.sidebar, height=1, fg_color=BORDER).pack(fill="x",padx=16,pady=8)

        self._nav_btns = {}
        nav_items = [
            ("🏠","Dashboard"), ("📸","Register"), ("🧠","Train"),
            ("🎥","Attendance"), ("📋","Records"),
            ("📊","Analytics"), ("📅","Schedule"), ("🤖","Assistant"),
        ]
        for icon, label in nav_items:
            b = ctk.CTkButton(self.sidebar, text=f"  {icon}   {label}",
                              anchor="w", font=("Segoe UI",13),
                              fg_color="transparent", text_color=MUTED,
                              hover_color=SURF2, corner_radius=8, height=40,
                              command=lambda l=label: self._nav(l))
            b.pack(fill="x", padx=10, pady=1)
            self._nav_btns[label] = b

        ctk.CTkFrame(self.sidebar, height=1, fg_color=BORDER).pack(
            fill="x", padx=16, pady=8, side="bottom")
        self.status_lbl = ctk.CTkLabel(self.sidebar, text="● Ready",
                                        font=("Segoe UI",11), text_color=GREEN)
        self.status_lbl.pack(side="bottom", pady=6)

        # Current subject indicator
        self.subj_lbl = ctk.CTkLabel(self.sidebar, text="",
                                      font=("Segoe UI",10), text_color=TEAL)
        self.subj_lbl.pack(side="bottom", pady=2)

        self.content = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        self.content.pack(side="left", fill="both", expand=True)

        self.pages = {}
        self._page_dashboard()
        self._page_register()
        self._page_train()
        self._page_attendance()
        self._page_records()
        self._page_analytics()
        self._page_schedule()
        self._page_assistant()

        self._update_subject_indicator()

    def _nav(self, label):
        if label != "Attendance" and self.camera_running:
            self._stop_cam()
        for l,b in self._nav_btns.items():
            b.configure(fg_color=ACCENT if l==label else "transparent",
                        text_color="white" if l==label else MUTED)
        for pg in self.pages.values(): pg.pack_forget()
        self.pages[label].pack(fill="both", expand=True, padx=24, pady=20)
        refresh_map = {
            "Dashboard": self._dash_refresh,
            "Train":     self._train_refresh_count,
            "Records":   self._records_refresh,
            "Analytics": self._analytics_refresh,
            "Schedule":  self._schedule_refresh,
            "Assistant": self._assistant_on_open,
        }
        if label in refresh_map: refresh_map[label]()

    def _update_subject_indicator(self):
        name, end = self.sched.current_slot()
        if name:
            self.subj_lbl.configure(text=f"📚 {name} (until {end})")
        else:
            self.subj_lbl.configure(text="")
        self.after(30000, self._update_subject_indicator)

    # ── SHARED HELPERS ─────────────────────────────────────────────────────────

    def _stat(self, parent, label, value, color, col):
        card = ctk.CTkFrame(parent, fg_color=SURFACE, corner_radius=10)
        card.grid(row=0, column=col, padx=5, sticky="ew", ipady=6)
        vl = ctk.CTkLabel(card, text=value,
                           font=("Segoe UI",24,"bold"), text_color=color)
        vl.pack(pady=(12,2))
        ctk.CTkLabel(card, text=label, font=("Segoe UI",11),
                     text_color=MUTED).pack(pady=(0,10))
        return vl

    def _section(self, parent, title):
        ctk.CTkLabel(parent, text=title, font=("Segoe UI",14,"bold"),
                     text_color=TEXT).pack(anchor="w", pady=(10,6))

    # ── PAGE: DASHBOARD ───────────────────────────────────────────────────────

    def _page_dashboard(self):
        pg = ctk.CTkFrame(self.content, fg_color="transparent")
        self.pages["Dashboard"] = pg

        ctk.CTkLabel(pg, text="Dashboard",
                     font=("Segoe UI",22,"bold"), text_color=TEXT).pack(anchor="w")
        self.dash_date = ctk.CTkLabel(pg, text="", font=("Segoe UI",12), text_color=MUTED)
        self.dash_date.pack(anchor="w", pady=(0,12))

        cards = ctk.CTkFrame(pg, fg_color="transparent")
        cards.pack(fill="x", pady=(0,14))
        cards.columnconfigure((0,1,2,3), weight=1)
        self.s_today    = self._stat(cards,"Present Today","—",GREEN,0)
        self.s_students = self._stat(cards,"Registered","—",BLUE,1)
        self.s_sessions = self._stat(cards,"Sessions","—",YELLOW,2)
        self.s_model    = self._stat(cards,"Model","—",MUTED,3)

        self._section(pg, "Quick Actions")
        acts = ctk.CTkFrame(pg, fg_color="transparent")
        acts.pack(fill="x", pady=(0,14))
        for i,(txt,col,cmd) in enumerate([
            ("📸  Register",   ACCENT,    lambda:self._nav("Register")),
            ("🎥  Attendance", "#238636", lambda:self._nav("Attendance")),
            ("📊  Analytics",  PURPLE,    lambda:self._nav("Analytics")),
            ("📅  Schedule",   TEAL[:7],  lambda:self._nav("Schedule")),
        ]):
            ctk.CTkButton(acts,text=txt,fg_color=col,height=44,
                          font=("Segoe UI",13),corner_radius=8,
                          command=cmd).grid(row=0,column=i,padx=5,sticky="ew")
            acts.columnconfigure(i,weight=1)

        self._section(pg, "Today's Attendance")
        self.dash_scroll = ctk.CTkScrollableFrame(pg,fg_color=SURFACE,
                                                   corner_radius=10,height=170)
        self.dash_scroll.pack(fill="x")

    def _dash_refresh(self):
        self.dash_date.configure(text=datetime.now().strftime("%A, %d %B %Y"))
        self.s_model.configure(
            text="✓ Ready" if os.path.exists(MODEL_PATH) else "✗ None",
            text_color=GREEN if os.path.exists(MODEL_PATH) else RED)
        n = 0
        if os.path.exists(NAMES_PATH):
            with open(NAMES_PATH,'rb') as f: n=len(pickle.load(f))
        self.s_students.configure(text=str(n))
        self.s_sessions.configure(
            text=str(len(glob.glob(os.path.join(ATTENDANCE_DIR,"*.csv")))))
        tf = os.path.join(ATTENDANCE_DIR,
             f"Attendance_{datetime.now().strftime('%Y-%m-%d')}.csv")
        rows = []
        if os.path.exists(tf):
            with open(tf) as f: rows=list(csv.DictReader(f))
        self.s_today.configure(text=str(len(rows)))
        for w in self.dash_scroll.winfo_children(): w.destroy()
        if rows:
            for row in reversed(rows[-10:]):
                item=ctk.CTkFrame(self.dash_scroll,fg_color=SURF2,corner_radius=6)
                item.pack(fill="x",pady=2,padx=4)
                subj = row.get("Subject","")
                lbl = f"✓  {row.get('Name','?')}"
                if subj: lbl += f"  [{subj}]"
                ctk.CTkLabel(item,text=lbl,font=("Segoe UI",12),text_color=GREEN).pack(
                    side="left",padx=10,pady=5)
                ctk.CTkLabel(item,text=row.get('Time',''),font=("Segoe UI",10),
                             text_color=MUTED).pack(side="right",padx=10)
        else:
            ctk.CTkLabel(self.dash_scroll,text="No attendance yet today.",
                         text_color=MUTED,font=("Segoe UI",12)).pack(pady=20)

    # ── PAGE: REGISTER ────────────────────────────────────────────────────────

    def _page_register(self):
        pg = ctk.CTkFrame(self.content, fg_color="transparent")
        self.pages["Register"] = pg
        ctk.CTkLabel(pg,text="Register New Student",
                     font=("Segoe UI",22,"bold"),text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(pg,text="Capture face photos — then train the model",
                     font=("Segoe UI",12),text_color=MUTED).pack(anchor="w",pady=(0,16))
        form=ctk.CTkFrame(pg,fg_color=SURFACE,corner_radius=12)
        form.pack(fill="x",pady=(0,12)); form.columnconfigure(1,weight=1)
        ctk.CTkLabel(form,text="Student Name",font=("Segoe UI",13),text_color=MUTED).grid(
            row=0,column=0,padx=20,pady=(18,8),sticky="w")
        self.reg_name_e=ctk.CTkEntry(form,placeholder_text="e.g. Rahul Sharma",
                                      height=38,font=("Segoe UI",13))
        self.reg_name_e.grid(row=0,column=1,padx=20,pady=(18,8),sticky="ew")
        ctk.CTkLabel(form,text="Student ID",font=("Segoe UI",13),text_color=MUTED).grid(
            row=1,column=0,padx=20,pady=8,sticky="w")
        self.reg_id_e=ctk.CTkEntry(form,placeholder_text="e.g. 1",height=38,font=("Segoe UI",13))
        self.reg_id_e.grid(row=1,column=1,padx=20,pady=8,sticky="ew")
        ctk.CTkLabel(form,text="Photos",font=("Segoe UI",13),text_color=MUTED).grid(
            row=2,column=0,padx=20,pady=8,sticky="w")
        sl_row=ctk.CTkFrame(form,fg_color="transparent")
        sl_row.grid(row=2,column=1,padx=20,pady=8,sticky="ew")
        self.reg_sl=ctk.CTkSlider(sl_row,from_=30,to=100,number_of_steps=7)
        self.reg_sl.set(60); self.reg_sl.pack(side="left",fill="x",expand=True)
        self.reg_sl_lbl=ctk.CTkLabel(sl_row,text="60",font=("Segoe UI",12),
                                      text_color=BLUE,width=30)
        self.reg_sl_lbl.pack(side="left",padx=8)
        self.reg_sl.configure(command=lambda v:self.reg_sl_lbl.configure(text=str(int(v))))
        self.reg_btn=ctk.CTkButton(form,text="📸   Start Camera & Capture",
                                    font=("Segoe UI",14,"bold"),height=48,
                                    fg_color=ACCENT,corner_radius=8,command=self._start_capture)
        self.reg_btn.grid(row=3,column=0,columnspan=2,padx=20,pady=(8,20),sticky="ew")
        self.reg_prog=ctk.CTkProgressBar(pg,height=8); self.reg_prog.set(0)
        self.reg_prog.pack(fill="x",pady=(0,8))
        self.reg_log=ctk.CTkTextbox(pg,height=220,font=("Consolas",12),
                                     fg_color=SURFACE,text_color=TEXT,corner_radius=10)
        self.reg_log.pack(fill="both",expand=True)
        self._rlog("Ready — enter student details and click Capture.\n")

    def _rlog(self,msg):
        self.reg_log.configure(state="normal")
        self.reg_log.insert("end",msg+"\n"); self.reg_log.see("end")
        self.reg_log.configure(state="disabled")

    def _start_capture(self):
        name=self.reg_name_e.get().strip(); sid_s=self.reg_id_e.get().strip()
        if not name or not sid_s:
            messagebox.showwarning("Missing Info","Enter both name and ID."); return
        try: sid=int(sid_s)
        except ValueError:
            messagebox.showerror("Invalid ID","ID must be a number."); return
        self.reg_btn.configure(state="disabled",text="Capturing...")
        self.reg_prog.set(0)
        threading.Thread(target=self._cap_thread,
                         args=(name,sid,int(self.reg_sl.get())),daemon=True).start()

    def _cap_thread(self,name,sid,n):
        os.makedirs(TRAINING_DIR,exist_ok=True)
        det=cv2.CascadeClassifier(CASCADE_PATH); cam=cv2.VideoCapture(0); count=0
        self.after(0,self._rlog,f"[INFO] Capturing {n} photos for {name}...")
        while count<n:
            ret,frame=cam.read()
            if not ret: break
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            for (x,y,w,h) in det.detectMultiScale(gray,1.3,5):
                count+=1
                cv2.imwrite(f"{TRAINING_DIR}/{name}.{sid}.{count}.jpg",gray[y:y+h,x:x+w])
                cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
                cv2.putText(frame,f"{count}/{n}",(10,30),cv2.FONT_HERSHEY_SIMPLEX,0.9,(0,255,0),2)
                self.after(0,self.reg_prog.set,count/n)
            cv2.imshow(f"Capturing {name}",frame)
            if cv2.waitKey(1)&0xFF==ord('q'): break
        cam.release(); cv2.destroyAllWindows()
        self.after(0,self._cap_done,name,count)

    def _cap_done(self,name,count):
        self._rlog(f"[SUCCESS] {count} images saved for {name}.")
        self._rlog("[→] Now click Train!\n")
        self.reg_btn.configure(state="normal",text="📸   Start Camera & Capture")
        self.reg_prog.set(1)
        self.status_lbl.configure(text=f"● {name} registered",text_color=GREEN)
        messagebox.showinfo("Done!",f"✓ {count} photos saved.\nNow click Train!")

    # ── PAGE: TRAIN ───────────────────────────────────────────────────────────

    def _page_train(self):
        pg=ctk.CTkFrame(self.content,fg_color="transparent")
        self.pages["Train"]=pg
        ctk.CTkLabel(pg,text="Train Model",font=("Segoe UI",22,"bold"),text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(pg,text="Run after registering any new student",
                     font=("Segoe UI",12),text_color=MUTED).pack(anchor="w",pady=(0,16))
        info=ctk.CTkFrame(pg,fg_color=SURFACE,corner_radius=12); info.pack(fill="x",pady=(0,12))
        self.train_count_lbl=ctk.CTkLabel(info,text="—",font=("Segoe UI",14),text_color=BLUE)
        self.train_count_lbl.pack(pady=16)
        self.train_btn=ctk.CTkButton(pg,text="🧠   Start Training",
                                      font=("Segoe UI",15,"bold"),height=54,
                                      fg_color="#238636",corner_radius=10,command=self._start_train)
        self.train_btn.pack(fill="x",pady=(0,12))
        self.train_prog=ctk.CTkProgressBar(pg,height=10); self.train_prog.set(0)
        self.train_prog.pack(fill="x",pady=(0,12))
        self.train_log=ctk.CTkTextbox(pg,font=("Consolas",12),fg_color=SURFACE,
                                       text_color=TEXT,corner_radius=10)
        self.train_log.pack(fill="both",expand=True)
        self._tlog("Ready.\n")

    def _tlog(self,msg):
        self.train_log.configure(state="normal")
        self.train_log.insert("end",msg+"\n"); self.train_log.see("end")
        self.train_log.configure(state="disabled")

    def _train_refresh_count(self):
        imgs=glob.glob(os.path.join(TRAINING_DIR,"*.jpg"))
        self.train_count_lbl.configure(text=f"{len(imgs)} training images found")

    def _start_train(self):
        self.train_btn.configure(state="disabled",text="Training...")
        self.train_prog.set(0)
        self.train_log.configure(state="normal"); self.train_log.delete("1.0","end")
        self.train_log.configure(state="disabled")
        threading.Thread(target=self._train_thread,daemon=True).start()

    def _train_thread(self):
        from PIL import Image as PILImage
        self.after(0,self._tlog,"[INFO] Starting training...")
        os.makedirs(p("TrainingImageLabel"),exist_ok=True)
        det=cv2.CascadeClassifier(CASCADE_PATH); rec=cv2.face.LBPHFaceRecognizer_create()
        imgs=[os.path.join(TRAINING_DIR,f) for f in os.listdir(TRAINING_DIR)
              if f.lower().endswith(('.jpg','.jpeg','.png'))]
        self.after(0,self._tlog,f"[INFO] {len(imgs)} images found.")
        faces,ids,id_to_name=[],[],{}
        for i,path in enumerate(imgs):
            fn=os.path.basename(path); parts=fn.split(".")
            try:    sid,sname=int(parts[1]),parts[0]
            except:
                try:    sid,sname=int(parts[0]),f"Student_{parts[0]}"
                except: continue
            id_to_name[sid]=sname
            img=np.array(PILImage.open(path).convert('L'),'uint8')
            for (x,y,w,h) in det.detectMultiScale(img,1.1,5):
                faces.append(img[y:y+h,x:x+w]); ids.append(sid)
            self.after(0,self.train_prog.set,(i+1)/len(imgs))
            if (i+1)%20==0: self.after(0,self._tlog,f"[INFO] {i+1}/{len(imgs)}...")
        if not faces:
            self.after(0,self._tlog,"[ERROR] No faces found.")
            self.after(0,self.train_btn.configure,{"state":"normal","text":"🧠   Start Training"})
            return
        self.after(0,self._tlog,f"[INFO] Training {len(faces)} samples...")
        rec.train(faces,np.array(ids)); rec.save(MODEL_PATH)
        with open(NAMES_PATH,'wb') as f: pickle.dump(id_to_name,f)
        self.after(0,self._tlog,f"[SUCCESS] {len(id_to_name)} students trained!\n")
        self.after(0,self.train_prog.set,1.0)
        self.after(0,self.train_btn.configure,{"state":"normal","text":"🧠   Start Training"})
        self.after(0,self.status_lbl.configure,{"text":"● Model ready","text_color":GREEN})
        self.after(0,messagebox.showinfo,"Done!",f"✓ {len(id_to_name)} students trained!")

    # ── PAGE: ATTENDANCE ──────────────────────────────────────────────────────

    def _page_attendance(self):
        pg=ctk.CTkFrame(self.content,fg_color="transparent")
        self.pages["Attendance"]=pg
        hdr=ctk.CTkFrame(pg,fg_color="transparent"); hdr.pack(fill="x",pady=(0,4))
        ctk.CTkLabel(hdr,text="Mark Attendance",font=("Segoe UI",22,"bold"),
                     text_color=TEXT).pack(side="left")
        self.att_exp_btn=ctk.CTkButton(hdr,text="⬇ Excel",width=90,height=36,
                                        fg_color=SURF2,font=("Segoe UI",12),
                                        corner_radius=8,command=self._export_excel)
        self.att_exp_btn.pack(side="right")
        self.att_btn=ctk.CTkButton(hdr,text="▶   Start Camera",width=150,height=36,
                                    fg_color="#238636",font=("Segoe UI",13,"bold"),
                                    corner_radius=8,command=self._toggle_cam)
        self.att_btn.pack(side="right",padx=(0,8))

        # Subject selector
        subj_row=ctk.CTkFrame(pg,fg_color="transparent"); subj_row.pack(fill="x",pady=(0,8))
        ctk.CTkLabel(subj_row,text="Subject:",font=("Segoe UI",12),text_color=MUTED).pack(side="left")
        self.att_subj_var=tk.StringVar(value="General")
        self.att_subj_menu=ctk.CTkOptionMenu(subj_row,variable=self.att_subj_var,
                                              values=["General"],
                                              font=("Segoe UI",12),width=200)
        self.att_subj_menu.pack(side="left",padx=8)

        # Session timer
        self.timer_lbl=ctk.CTkLabel(subj_row,text="",
                                     font=("Segoe UI Emoji",12),text_color=YELLOW)
        self.timer_lbl.pack(side="left",padx=12)

        ctk.CTkLabel(pg,text="Live detection — attendance marked automatically",
                     font=("Segoe UI",12),text_color=MUTED).pack(anchor="w",pady=(0,8))

        body=ctk.CTkFrame(pg,fg_color="transparent"); body.pack(fill="both",expand=True)
        body.columnconfigure(0,weight=3); body.columnconfigure(1,weight=1)
        cam_f=ctk.CTkFrame(body,fg_color=SURFACE,corner_radius=12)
        cam_f.grid(row=0,column=0,sticky="nsew",padx=(0,8))
        self.cam_lbl=ctk.CTkLabel(cam_f,text="📷\n\nClick ▶ Start Camera",
                                   font=("Segoe UI",14),text_color=MUTED)
        self.cam_lbl.pack(fill="both",expand=True,padx=8,pady=8)
        log_f=ctk.CTkFrame(body,fg_color=SURFACE,corner_radius=12)
        log_f.grid(row=0,column=1,sticky="nsew")
        ctk.CTkLabel(log_f,text="Today's Log",font=("Segoe UI",13,"bold"),
                     text_color=TEXT).pack(pady=(12,4),padx=12,anchor="w")
        ctk.CTkFrame(log_f,height=1,fg_color=BORDER).pack(fill="x",padx=12)
        self.att_log_scroll=ctk.CTkScrollableFrame(log_f,fg_color="transparent")
        self.att_log_scroll.pack(fill="both",expand=True,padx=8,pady=8)
        self.att_count_lbl=ctk.CTkLabel(log_f,text="Marked: 0",
                                         font=("Segoe UI",12),text_color=GREEN)
        self.att_count_lbl.pack(pady=(0,10))

        self._refresh_subject_menu()

    def _refresh_subject_menu(self):
        subjects = ["General"] + [s["name"] for s in self.sched.data["subjects"]]
        self.att_subj_menu.configure(values=subjects)

    def _toggle_cam(self):
        if self.camera_running: self._stop_cam()
        else:                   self._start_cam()

    def _start_cam(self):
        rec,id_to_name=load_model()
        if rec is None:
            messagebox.showerror("No Model","Train the model first."); return

        # check holiday
        if self.sched.is_holiday():
            if not messagebox.askyesno("Holiday",
                "Today is marked as a holiday!\nStart attendance anyway?"):
                return

        self.camera_running=True
        self.att_btn.configure(text="⏹   Stop Camera",fg_color=RED)
        self.marked_today.clear()
        for w in self.att_log_scroll.winfo_children(): w.destroy()
        self.att_count_lbl.configure(text="Marked: 0")

        subj_name=self.att_subj_var.get()
        subj_id=None
        for s in self.sched.data["subjects"]:
            if s["name"]==subj_name: subj_id=s["id"]; break

        att_file = self.sched.get_attendance_file(subj_id)
        cascade  = cv2.CascadeClassifier(CASCADE_PATH)
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,854)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)

        # Session timer
        dur = self.sched.data.get("session_minutes",60) * 60
        self.session_seconds = [dur]
        self._tick_timer()

        fq=queue.Queue(maxsize=2); rq=queue.Queue()
        def worker():
            while self.camera_running:
                try: frame=fq.get(timeout=0.5)
                except queue.Empty: continue
                small=cv2.resize(frame,(0,0),fx=0.5,fy=0.5)
                gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
                faces=cascade.detectMultiScale(gray,1.2,5,minSize=(30,30))
                results=[]
                for (x,y,w,h) in faces:
                    sid,conf=rec.predict(gray[y:y+h,x:x+w])
                    if conf<CONFIDENCE_THRESH:
                        name=id_to_name.get(sid,f"ID:{sid}")
                        results.append((x*2,y*2,w*2,h*2,name,sid,conf,True))
                    else:
                        results.append((x*2,y*2,w*2,h*2,"Unknown",-1,conf,False))
                rq.put(results)
        threading.Thread(target=worker,daemon=True).start()

        fc=[0]; lr=[[]]
        def update():
            if not self.camera_running: return
            ret,frame=self.cap.read()
            if not ret: self.after(30,update); return
            fc[0]+=1
            if fc[0]%3==0 and not fq.full(): fq.put(frame.copy())
            try: lr[0]=rq.get_nowait()
            except queue.Empty: pass
            for (x,y,w,h,name,sid,conf,known) in lr[0]:
                col=(0,210,70) if known else (0,50,220)
                draw_corner_box(frame,x,y,w,h,col)
                put_label(frame,f"{name} {int(100-conf)}%" if known else "Unknown",
                          x,max(y-14,14),col,(0,40,0) if known else (40,0,0))
                if known and sid not in self.marked_today:
                    t_str=datetime.now().strftime("%H:%M:%S")
                    if mark_attendance(sid,name,subj_name,att_file,self.marked_today):
                        self.after(0,self._add_log_entry,name,t_str,subj_name)
                        self.after(0,self.att_count_lbl.configure,
                                   {"text":f"Marked: {len(self.marked_today)}"})
            cv2.putText(frame,datetime.now().strftime("%H:%M:%S"),
                        (10,24),cv2.FONT_HERSHEY_SIMPLEX,0.6,(160,160,160),1,cv2.LINE_AA)
            rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            img=Image.fromarray(rgb)
            ww,wh=self.cam_lbl.winfo_width(),self.cam_lbl.winfo_height()
            if ww>10 and wh>10: img=img.resize((ww,wh),Image.LANCZOS)
            itk=ImageTk.PhotoImage(img)
            self.cam_lbl.configure(image=itk,text=""); self.cam_lbl.image=itk
            self.after(30,update)
        self.after(100,update)

    def _tick_timer(self):
        if not self.camera_running: return
        secs = self.session_seconds[0]
        if secs <= 0:
            self.timer_lbl.configure(text="⏰ Session ended!")
            self._stop_cam()
            messagebox.showinfo("Session Over","Class session time is up!\nAttendance saved.")
            return
        m,s = divmod(secs, 60)
        col = RED if secs < 300 else YELLOW if secs < 600 else GREEN
        self.timer_lbl.configure(text=f"⏱ {m:02d}:{s:02d}", text_color=col)
        self.session_seconds[0] -= 1
        self.after(1000, self._tick_timer)

    def _stop_cam(self):
        self.camera_running=False
        if self.cap: self.cap.release(); self.cap=None
        self.att_btn.configure(text="▶   Start Camera",fg_color="#238636")
        self.cam_lbl.configure(image=None,
                                text=f"✓ Session ended — {len(self.marked_today)} marked")
        self.timer_lbl.configure(text="")
        self.status_lbl.configure(text=f"● {len(self.marked_today)} marked",text_color=GREEN)
        self._dash_refresh(); self._records_refresh()

    def _add_log_entry(self,name,t,subj=""):
        item=ctk.CTkFrame(self.att_log_scroll,fg_color=SURF2,corner_radius=6)
        item.pack(fill="x",pady=2)
        lbl = f"✓  {name}" + (f"  [{subj}]" if subj and subj!="General" else "")
        ctk.CTkLabel(item,text=lbl,font=("Segoe UI",12),text_color=GREEN).pack(
            side="left",padx=8,pady=5)
        ctk.CTkLabel(item,text=t,font=("Segoe UI",10),text_color=MUTED).pack(
            side="right",padx=8)

    def _export_excel(self):
        try:
            import openpyxl
            subj_name=self.att_subj_var.get() if hasattr(self,'att_subj_var') else "General"
            subj_id=None
            for s in self.sched.data["subjects"]:
                if s["name"]==subj_name: subj_id=s["id"]; break
            tf=self.sched.get_attendance_file(subj_id)
            wb=openpyxl.Workbook(); ws=wb.active; ws.title="Attendance"

            # Style header
            from openpyxl.styles import PatternFill, Font, Alignment
            header_fill=PatternFill("solid",fgColor="1F6FEB")
            with open(tf) as f:
                for ri,row in enumerate(csv.reader(f)):
                    ws.append(row)
                    if ri==0:
                        for cell in ws[1]:
                            cell.fill=header_fill
                            cell.font=Font(color="FFFFFF",bold=True)
                            cell.alignment=Alignment(horizontal="center")
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width=18
            xf=tf.replace('.csv','.xlsx'); wb.save(xf)
            messagebox.showinfo("Exported!",f"✓ Excel saved:\n{xf}")
        except Exception as e:
            messagebox.showerror("Error",str(e))

    # ── PAGE: RECORDS ─────────────────────────────────────────────────────────

    def _page_records(self):
        pg=ctk.CTkFrame(self.content,fg_color="transparent"); self.pages["Records"]=pg
        hdr=ctk.CTkFrame(pg,fg_color="transparent"); hdr.pack(fill="x",pady=(0,10))
        ctk.CTkLabel(hdr,text="Attendance Records",font=("Segoe UI",22,"bold"),
                     text_color=TEXT).pack(side="left")
        ctk.CTkButton(hdr,text="⬇ Excel",width=110,height=34,fg_color=ACCENT,
                      font=("Segoe UI",12),command=self._export_excel).pack(side="right")
        ctk.CTkButton(hdr,text="↻",width=50,height=34,fg_color=SURF2,
                      font=("Segoe UI",12),command=self._records_refresh).pack(side="right",padx=(0,8))
        ctrl=ctk.CTkFrame(pg,fg_color="transparent"); ctrl.pack(fill="x",pady=(0,10))
        self.rec_var=tk.StringVar()
        self.rec_menu=ctk.CTkOptionMenu(ctrl,variable=self.rec_var,values=["No files yet"],
                                         command=self._load_file,font=("Segoe UI",12),width=260)
        self.rec_menu.pack(side="left")
        self.rec_search=ctk.CTkEntry(ctrl,placeholder_text="Search...",
                                      height=34,font=("Segoe UI",12),width=180)
        self.rec_search.pack(side="left",padx=10)
        self.rec_search.bind("<KeyRelease>",lambda e:self._filter_records())
        tbl_f=ctk.CTkFrame(pg,fg_color=SURFACE,corner_radius=10); tbl_f.pack(fill="both",expand=True)
        style=ttk.Style(); style.theme_use("clam")
        style.configure("A.Treeview",background=SURFACE,foreground=TEXT,rowheight=30,
                         fieldbackground=SURFACE,borderwidth=0,font=("Segoe UI",12))
        style.configure("A.Treeview.Heading",background=SURF2,foreground=MUTED,
                         font=("Segoe UI",11,"bold"),borderwidth=0)
        style.map("A.Treeview",background=[("selected",ACCENT)],foreground=[("selected","white")])
        cols=("No","Name","ID","Subject","Date","Time")
        self.tree=ttk.Treeview(tbl_f,columns=cols,show="headings",style="A.Treeview")
        widths={"No":50,"Name":160,"ID":70,"Subject":130,"Date":110,"Time":90}
        for c in cols:
            self.tree.heading(c,text=c); self.tree.column(c,width=widths.get(c,100),anchor="w")
        sb=ttk.Scrollbar(tbl_f,orient="vertical",command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right",fill="y"); self.tree.pack(fill="both",expand=True,padx=2,pady=2)
        self.rec_count=ctk.CTkLabel(pg,text="",font=("Segoe UI",11),text_color=MUTED)
        self.rec_count.pack(anchor="e",pady=(5,0))

    def _records_refresh(self):
        files=sorted(glob.glob(os.path.join(ATTENDANCE_DIR,"*.csv")),reverse=True)
        if not files: self.rec_menu.configure(values=["No records yet"]); return
        labels=[]; self._file_label_map={}
        for f in files:
            fn=os.path.basename(f)
            try:
                parts=fn.replace(".csv","").split("_",2)
                d=parts[1]
                subj=" — "+parts[2].replace("_"," ") if len(parts)>2 else ""
                dt=datetime.strptime(d,"%Y-%m-%d")
                lbl=("Today" if d==datetime.now().strftime("%Y-%m-%d") else dt.strftime("%d %b %Y"))+subj
            except: lbl=fn
            labels.append(lbl); self._file_label_map[lbl]=f
        self.rec_menu.configure(values=labels)
        self.rec_var.set(labels[0]); self._load_file(labels[0])

    def _load_file(self,label):
        path=self._file_label_map.get(label,"")
        if not path or not os.path.exists(path): return
        with open(path) as f: self._all_records=list(csv.DictReader(f))
        self._filter_records()

    def _filter_records(self):
        q=self.rec_search.get().lower()
        rows=[r for r in self._all_records
              if q in r.get("Name","").lower() or q in str(r.get("ID",""))]
        for i in self.tree.get_children(): self.tree.delete(i)
        for i,r in enumerate(rows,1):
            self.tree.insert("","end",values=(
                i,r.get("Name",""),r.get("ID",""),
                r.get("Subject",""),r.get("Date",""),r.get("Time","")))
        self.rec_count.configure(text=f"{len(rows)} records")

    # ══════════════════════════════════════════════════════════════════════════
    #  PAGE: ANALYTICS  ★ NEW ★
    # ══════════════════════════════════════════════════════════════════════════

    def _page_analytics(self):
        pg=ctk.CTkFrame(self.content,fg_color="transparent"); self.pages["Analytics"]=pg

        hdr=ctk.CTkFrame(pg,fg_color="transparent"); hdr.pack(fill="x",pady=(0,4))
        ctk.CTkLabel(hdr,text="Analytics",font=("Segoe UI",22,"bold"),text_color=TEXT).pack(side="left")
        ctk.CTkButton(hdr,text="↻ Refresh",width=100,height=34,fg_color=SURF2,
                      font=("Segoe UI",12),command=self._analytics_refresh).pack(side="right")
        ctk.CTkButton(hdr,text="⬇ Report",width=110,height=34,fg_color=ACCENT,
                      font=("Segoe UI",12),command=self._export_report).pack(side="right",padx=(0,8))

        ctk.CTkLabel(pg,text="Attendance charts, percentages and monthly summary",
                     font=("Segoe UI",12),text_color=MUTED).pack(anchor="w",pady=(0,10))

        # Top stat cards
        cards=ctk.CTkFrame(pg,fg_color="transparent"); cards.pack(fill="x",pady=(0,12))
        cards.columnconfigure((0,1,2,3),weight=1)
        self.a_avg    = self._stat(cards,"Avg Attendance","—%",BLUE,0)
        self.a_above  = self._stat(cards,"Above 75%","—",GREEN,1)
        self.a_below  = self._stat(cards,"Below 75%","—",RED,2)
        self.a_perfect= self._stat(cards,"100% Present","—",YELLOW,3)

        # Charts side by side
        charts_row=ctk.CTkFrame(pg,fg_color="transparent"); charts_row.pack(fill="both",expand=True)
        charts_row.columnconfigure(0,weight=3); charts_row.columnconfigure(1,weight=2)

        # Bar chart
        bar_f=ctk.CTkFrame(charts_row,fg_color=SURFACE,corner_radius=12)
        bar_f.grid(row=0,column=0,sticky="nsew",padx=(0,6))
        self.bar_canvas=tk.Canvas(bar_f,bg=SURFACE,highlightthickness=0)
        self.bar_canvas.pack(fill="both",expand=True,padx=4,pady=4)

        # Right column: line chart + alert list
        right_f=ctk.CTkFrame(charts_row,fg_color="transparent")
        right_f.grid(row=0,column=1,sticky="nsew")
        right_f.rowconfigure(0,weight=1); right_f.rowconfigure(1,weight=1)

        line_f=ctk.CTkFrame(right_f,fg_color=SURFACE,corner_radius=12)
        line_f.grid(row=0,column=0,sticky="nsew",pady=(0,6))
        self.line_canvas=tk.Canvas(line_f,bg=SURFACE,highlightthickness=0)
        self.line_canvas.pack(fill="both",expand=True,padx=4,pady=4)

        alert_f=ctk.CTkFrame(right_f,fg_color=SURFACE,corner_radius=12)
        alert_f.grid(row=1,column=0,sticky="nsew")
        ctk.CTkLabel(alert_f,text="⚠ Low Attendance Alerts",
                     font=("Segoe UI",12,"bold"),text_color=RED).pack(
            anchor="w",padx=12,pady=(10,4))
        ctk.CTkFrame(alert_f,height=1,fg_color=BORDER).pack(fill="x",padx=12)
        self.alert_scroll=ctk.CTkScrollableFrame(alert_f,fg_color="transparent",height=120)
        self.alert_scroll.pack(fill="both",expand=True,padx=8,pady=6)

    def _analytics_refresh(self):
        stats    = self.analytics.student_stats()
        daily    = self.analytics.daily_totals()

        if not stats:
            self.a_avg.configure(text="—%")
            self.a_above.configure(text="—")
            self.a_below.configure(text="—")
            self.a_perfect.configure(text="—")
            return

        pcts     = [d["pct"] for d in stats.values()]
        avg      = round(sum(pcts)/len(pcts),1) if pcts else 0
        above    = sum(1 for p in pcts if p>=75)
        below    = sum(1 for p in pcts if p<75)
        perfect  = sum(1 for p in pcts if p==100)

        self.a_avg.configure(text=f"{avg}%",
                              text_color=GREEN if avg>=75 else RED)
        self.a_above.configure(text=str(above))
        self.a_below.configure(text=str(below))
        self.a_perfect.configure(text=str(perfect))

        # Draw charts after widget has rendered
        self.after(100, self._draw_charts, stats, daily)

        # Alerts
        for w in self.alert_scroll.winfo_children(): w.destroy()
        low = [(n,d["pct"]) for n,d in stats.items() if d["pct"]<75]
        low.sort(key=lambda x:x[1])
        if low:
            for name,pct in low:
                row=ctk.CTkFrame(self.alert_scroll,fg_color=SURF2,corner_radius=6)
                row.pack(fill="x",pady=2)
                ctk.CTkLabel(row,text=f"⚠  {name}",font=("Segoe UI",12),
                             text_color=RED).pack(side="left",padx=8,pady=4)
                bar_w = int(pct/100*80)
                pct_lbl=f"{pct}%"
                ctk.CTkLabel(row,text=pct_lbl,font=("Segoe UI",11,"bold"),
                             text_color=YELLOW).pack(side="right",padx=8)
        else:
            ctk.CTkLabel(self.alert_scroll,text="✅ All students above 75%",
                         text_color=GREEN,font=("Segoe UI",12)).pack(pady=10)

    def _draw_charts(self, stats, daily):
        # Bar chart
        w=self.bar_canvas.winfo_width()
        h=self.bar_canvas.winfo_height()
        if w>10 and h>10:
            bar_data={n:d["pct"] for n,d in stats.items()}
            draw_bar_chart(self.bar_canvas,bar_data,w,h)

        # Line chart
        w2=self.line_canvas.winfo_width()
        h2=self.line_canvas.winfo_height()
        if w2>10 and h2>10:
            draw_line_chart(self.line_canvas,daily,w2,h2)

    def _export_report(self):
        """Export a styled Excel monthly report."""
        try:
            import openpyxl
            from openpyxl.styles import PatternFill,Font,Alignment,Border,Side

            stats   = self.analytics.student_stats()
            if not stats:
                messagebox.showwarning("No Data","No attendance data found."); return

            wb=openpyxl.Workbook(); ws=wb.active
            ws.title="Attendance Report"
            month=datetime.now().strftime("%B %Y")
            ws.merge_cells("A1:F1")
            ws["A1"]=f"Attendance Report — {month}"
            ws["A1"].font=Font(size=16,bold=True,color="FFFFFF")
            ws["A1"].fill=PatternFill("solid",fgColor="1F6FEB")
            ws["A1"].alignment=Alignment(horizontal="center")
            ws.row_dimensions[1].height=30

            headers=["Student Name","Sessions Present","Total Sessions","Percentage","Status"]
            for ci,h in enumerate(headers,1):
                cell=ws.cell(row=2,column=ci,value=h)
                cell.font=Font(bold=True,color="FFFFFF")
                cell.fill=PatternFill("solid",fgColor="21262D")
                cell.alignment=Alignment(horizontal="center")

            for ri,(name,d) in enumerate(sorted(stats.items()),3):
                pct=d["pct"]
                status="✓ Good" if pct>=75 else "⚠ Low" if pct>=50 else "✗ Critical"
                row_data=[name,d["present"],d["total_sessions"],f"{pct}%",status]
                for ci,val in enumerate(row_data,1):
                    cell=ws.cell(row=ri,column=ci,value=val)
                    cell.alignment=Alignment(horizontal="center")
                    if ci==4:
                        cell.font=Font(bold=True,
                            color="3FB950" if pct>=75 else "E3B341" if pct>=50 else "F85149")
                if ri%2==0:
                    for ci in range(1,6):
                        ws.cell(row=ri,column=ci).fill=PatternFill("solid",fgColor="161B22")

            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width=20

            fname=p(f"Report_{datetime.now().strftime('%Y-%m')}.xlsx")
            wb.save(fname)
            messagebox.showinfo("Report Exported!",f"✓ Monthly report saved:\n{fname}")
        except Exception as e:
            messagebox.showerror("Error",str(e))

    # ══════════════════════════════════════════════════════════════════════════
    #  PAGE: SCHEDULE  ★ NEW ★
    # ══════════════════════════════════════════════════════════════════════════

    def _page_schedule(self):
        pg=ctk.CTkFrame(self.content,fg_color="transparent"); self.pages["Schedule"]=pg

        ctk.CTkLabel(pg,text="Schedule & Classes",
                     font=("Segoe UI",22,"bold"),text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(pg,text="Manage subjects, timetable, holidays and session settings",
                     font=("Segoe UI",12),text_color=MUTED).pack(anchor="w",pady=(0,12))

        # Two columns
        body=ctk.CTkFrame(pg,fg_color="transparent"); body.pack(fill="both",expand=True)
        body.columnconfigure(0,weight=1); body.columnconfigure(1,weight=1)

        # ── LEFT: Subjects ────────────────────────────────────────────────────
        left=ctk.CTkFrame(body,fg_color=SURFACE,corner_radius=12)
        left.grid(row=0,column=0,sticky="nsew",padx=(0,8),pady=(0,8))

        subj_hdr=ctk.CTkFrame(left,fg_color="transparent"); subj_hdr.pack(fill="x",padx=12,pady=(12,6))
        ctk.CTkLabel(subj_hdr,text="Subjects",font=("Segoe UI",14,"bold"),
                     text_color=TEXT).pack(side="left")
        ctk.CTkButton(subj_hdr,text="+ Add",width=70,height=28,
                      fg_color=ACCENT,font=("Segoe UI",11),
                      command=self._add_subject_dialog).pack(side="right")

        ctk.CTkFrame(left,height=1,fg_color=BORDER).pack(fill="x",padx=12)
        self.subj_scroll=ctk.CTkScrollableFrame(left,fg_color="transparent",height=140)
        self.subj_scroll.pack(fill="x",padx=8,pady=8)

        # Session duration
        ctk.CTkFrame(left,height=1,fg_color=BORDER).pack(fill="x",padx=12)
        dur_row=ctk.CTkFrame(left,fg_color="transparent"); dur_row.pack(fill="x",padx=12,pady=10)
        ctk.CTkLabel(dur_row,text="Session duration (min):",
                     font=("Segoe UI",12),text_color=MUTED).pack(side="left")
        self.dur_entry=ctk.CTkEntry(dur_row,width=60,height=30,font=("Segoe UI",12))
        self.dur_entry.insert(0,str(self.sched.data.get("session_minutes",60)))
        self.dur_entry.pack(side="left",padx=8)
        ctk.CTkButton(dur_row,text="Save",width=60,height=30,
                      fg_color=SURF2,font=("Segoe UI",11),
                      command=self._save_duration).pack(side="left")

        # ── RIGHT: Timetable ──────────────────────────────────────────────────
        right=ctk.CTkFrame(body,fg_color=SURFACE,corner_radius=12)
        right.grid(row=0,column=1,sticky="nsew",pady=(0,8))

        slot_hdr=ctk.CTkFrame(right,fg_color="transparent"); slot_hdr.pack(fill="x",padx=12,pady=(12,6))
        ctk.CTkLabel(slot_hdr,text="Timetable",font=("Segoe UI",14,"bold"),
                     text_color=TEXT).pack(side="left")
        ctk.CTkButton(slot_hdr,text="+ Add Slot",width=90,height=28,
                      fg_color=ACCENT,font=("Segoe UI",11),
                      command=self._add_slot_dialog).pack(side="right")

        ctk.CTkFrame(right,height=1,fg_color=BORDER).pack(fill="x",padx=12)
        self.slot_scroll=ctk.CTkScrollableFrame(right,fg_color="transparent",height=170)
        self.slot_scroll.pack(fill="both",expand=True,padx=8,pady=8)

        # ── BOTTOM: Holidays ──────────────────────────────────────────────────
        bot=ctk.CTkFrame(body,fg_color=SURFACE,corner_radius=12)
        bot.grid(row=1,column=0,columnspan=2,sticky="nsew",pady=(0,0))

        hol_hdr=ctk.CTkFrame(bot,fg_color="transparent"); hol_hdr.pack(fill="x",padx=12,pady=(12,6))
        ctk.CTkLabel(hol_hdr,text="Holidays",font=("Segoe UI",14,"bold"),
                     text_color=TEXT).pack(side="left")

        hol_input=ctk.CTkFrame(bot,fg_color="transparent"); hol_input.pack(fill="x",padx=12,pady=(0,8))
        self.hol_entry=ctk.CTkEntry(hol_input,placeholder_text="YYYY-MM-DD  (e.g. 2026-04-14)",
                                     height=32,font=("Segoe UI",12),width=240)
        self.hol_entry.pack(side="left")
        ctk.CTkButton(hol_input,text="Add Holiday",width=110,height=32,
                      fg_color=ORANGE,font=("Segoe UI",12),
                      command=self._add_holiday).pack(side="left",padx=8)

        ctk.CTkFrame(bot,height=1,fg_color=BORDER).pack(fill="x",padx=12)
        self.hol_scroll=ctk.CTkScrollableFrame(bot,fg_color="transparent",height=80)
        self.hol_scroll.pack(fill="x",padx=8,pady=6)

    def _schedule_refresh(self):
        self._refresh_subjects_list()
        self._refresh_slots_list()
        self._refresh_holidays_list()
        self._refresh_subject_menu()

    def _refresh_subjects_list(self):
        for w in self.subj_scroll.winfo_children(): w.destroy()
        if not self.sched.data["subjects"]:
            ctk.CTkLabel(self.subj_scroll,text="No subjects yet. Click + Add.",
                         text_color=MUTED,font=("Segoe UI",11)).pack(pady=8)
            return
        for s in self.sched.data["subjects"]:
            row=ctk.CTkFrame(self.subj_scroll,fg_color=SURF2,corner_radius=6)
            row.pack(fill="x",pady=2)
            dot=ctk.CTkFrame(row,width=12,height=12,corner_radius=6,
                              fg_color=s.get("color",BLUE))
            dot.pack(side="left",padx=(10,6),pady=8)
            ctk.CTkLabel(row,text=s["name"],font=("Segoe UI",12),
                         text_color=TEXT).pack(side="left")
            ctk.CTkButton(row,text="✕",width=28,height=24,
                          fg_color="transparent",text_color=RED,
                          hover_color=SURF2,font=("Segoe UI",11),
                          command=lambda sid=s["id"]:self._delete_subject(sid)
                          ).pack(side="right",padx=6)

    def _refresh_slots_list(self):
        for w in self.slot_scroll.winfo_children(): w.destroy()
        subj_map={s["id"]:s for s in self.sched.data["subjects"]}
        days_order=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        slots=sorted(self.sched.data["slots"],
                     key=lambda sl:(days_order.index(sl["day"]) if sl["day"] in days_order else 9,
                                    sl["start"]))
        if not slots:
            ctk.CTkLabel(self.slot_scroll,text="No slots yet. Click + Add Slot.",
                         text_color=MUTED,font=("Segoe UI",11)).pack(pady=8)
            return
        for i,sl in enumerate(slots):
            subj=subj_map.get(sl["subject_id"],{})
            row=ctk.CTkFrame(self.slot_scroll,fg_color=SURF2,corner_radius=6)
            row.pack(fill="x",pady=2)
            day_lbl=sl["day"][:3]
            ctk.CTkLabel(row,text=day_lbl,font=("Segoe UI",11,"bold"),
                         text_color=TEAL,width=36).pack(side="left",padx=(10,4),pady=6)
            ctk.CTkLabel(row,text=f"{sl['start']} – {sl['end']}",
                         font=("Segoe UI",11),text_color=MUTED).pack(side="left",padx=4)
            ctk.CTkLabel(row,text=subj.get("name","?"),
                         font=("Segoe UI",12),text_color=TEXT).pack(side="left",padx=8)
            ctk.CTkButton(row,text="✕",width=28,height=24,
                          fg_color="transparent",text_color=RED,hover_color=SURF2,
                          font=("Segoe UI",11),
                          command=lambda idx=i:self._delete_slot(idx)
                          ).pack(side="right",padx=6)

    def _refresh_holidays_list(self):
        for w in self.hol_scroll.winfo_children(): w.destroy()
        hols=sorted(self.sched.data["holidays"])
        if not hols:
            ctk.CTkLabel(self.hol_scroll,text="No holidays added.",
                         text_color=MUTED,font=("Segoe UI",11)).pack(pady=6)
            return
        for h in hols:
            row=ctk.CTkFrame(self.hol_scroll,fg_color=SURF2,corner_radius=6)
            row.pack(side="left",padx=4,pady=2)
            try:
                dt=datetime.strptime(h,"%Y-%m-%d")
                lbl=dt.strftime("%d %b %Y")
            except: lbl=h
            ctk.CTkLabel(row,text=f"🎉 {lbl}",font=("Segoe UI",11),
                         text_color=ORANGE).pack(side="left",padx=8,pady=5)
            ctk.CTkButton(row,text="✕",width=24,height=22,
                          fg_color="transparent",text_color=RED,hover_color=SURF2,
                          font=("Segoe UI",10),
                          command=lambda d=h:self._remove_holiday(d)
                          ).pack(side="left",padx=4)

    def _add_subject_dialog(self):
        dlg=ctk.CTkToplevel(self)
        dlg.title("Add Subject"); dlg.geometry("340x180"); dlg.resizable(False,False)
        dlg.configure(fg_color=SURFACE); dlg.grab_set()
        ctk.CTkLabel(dlg,text="Subject Name",font=("Segoe UI",13),text_color=MUTED).pack(pady=(18,4))
        name_e=ctk.CTkEntry(dlg,placeholder_text="e.g. Mathematics",
                              height=38,font=("Segoe UI",13),width=280)
        name_e.pack()
        chosen_color=[BLUE]
        color_row=ctk.CTkFrame(dlg,fg_color="transparent"); color_row.pack(pady=8)
        color_dot=ctk.CTkFrame(color_row,width=24,height=24,corner_radius=12,fg_color=BLUE)
        color_dot.pack(side="left",padx=6)
        def pick_color():
            c=colorchooser.askcolor(color=chosen_color[0],title="Pick colour")
            if c[1]:
                chosen_color[0]=c[1]
                color_dot.configure(fg_color=c[1])
        ctk.CTkButton(color_row,text="Pick Color",width=100,height=28,
                      fg_color=SURF2,font=("Segoe UI",11),
                      command=pick_color).pack(side="left")
        def save():
            n=name_e.get().strip()
            if not n: return
            self.sched.add_subject(n,chosen_color[0])
            self._schedule_refresh(); dlg.destroy()
        ctk.CTkButton(dlg,text="Add Subject",height=36,fg_color=ACCENT,
                      font=("Segoe UI",13),command=save).pack(pady=6,padx=20,fill="x")

    def _add_slot_dialog(self):
        if not self.sched.data["subjects"]:
            messagebox.showwarning("No Subjects","Add subjects first."); return
        dlg=ctk.CTkToplevel(self)
        dlg.title("Add Timetable Slot"); dlg.geometry("360x280"); dlg.resizable(False,False)
        dlg.configure(fg_color=SURFACE); dlg.grab_set()
        fields=ctk.CTkFrame(dlg,fg_color="transparent"); fields.pack(padx=20,pady=16,fill="x")
        fields.columnconfigure(1,weight=1)
        labels=["Day","Start (HH:MM)","End (HH:MM)","Subject"]
        defaults=["Monday","09:00","10:00",self.sched.data["subjects"][0]["name"]]
        entries={}
        for i,(lbl,dflt) in enumerate(zip(labels,defaults)):
            ctk.CTkLabel(fields,text=lbl,font=("Segoe UI",12),text_color=MUTED).grid(
                row=i,column=0,sticky="w",pady=5)
            if lbl=="Day":
                days=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
                var=tk.StringVar(value=dflt)
                w=ctk.CTkOptionMenu(fields,variable=var,values=days,font=("Segoe UI",12))
                w.grid(row=i,column=1,sticky="ew",padx=(10,0),pady=5)
                entries[lbl]=var
            elif lbl=="Subject":
                var=tk.StringVar(value=dflt)
                w=ctk.CTkOptionMenu(fields,variable=var,
                                     values=[s["name"] for s in self.sched.data["subjects"]],
                                     font=("Segoe UI",12))
                w.grid(row=i,column=1,sticky="ew",padx=(10,0),pady=5)
                entries[lbl]=var
            else:
                e=ctk.CTkEntry(fields,placeholder_text=dflt,height=34,font=("Segoe UI",12))
                e.insert(0,dflt); e.grid(row=i,column=1,sticky="ew",padx=(10,0),pady=5)
                entries[lbl]=e
        def save():
            day=entries["Day"].get()
            start=entries["Start (HH:MM)"].get().strip()
            end=entries["End (HH:MM)"].get().strip()
            subj_name=entries["Subject"].get()
            subj_id=next((s["id"] for s in self.sched.data["subjects"]
                           if s["name"]==subj_name),None)
            if not start or not end or not subj_id: return
            self.sched.add_slot(day,start,end,subj_id)
            self._schedule_refresh(); dlg.destroy()
        ctk.CTkButton(dlg,text="Add Slot",height=38,fg_color=ACCENT,
                      font=("Segoe UI",13),command=save).pack(padx=20,pady=6,fill="x")

    def _delete_subject(self,sid):
        if messagebox.askyesno("Delete","Delete this subject and its slots?"):
            self.sched.delete_subject(sid); self._schedule_refresh()

    def _delete_slot(self,idx):
        self.sched.delete_slot(idx); self._schedule_refresh()

    def _add_holiday(self):
        d=self.hol_entry.get().strip()
        try: datetime.strptime(d,"%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Invalid","Use format YYYY-MM-DD"); return
        self.sched.add_holiday(d); self.hol_entry.delete(0,"end")
        self._refresh_holidays_list()

    def _remove_holiday(self,d):
        self.sched.remove_holiday(d); self._refresh_holidays_list()

    def _save_duration(self):
        try:
            mins=int(self.dur_entry.get())
            self.sched.data["session_minutes"]=mins; self.sched.save()
            self.status_lbl.configure(text=f"● Duration: {mins}min",text_color=GREEN)
        except ValueError:
            messagebox.showerror("Invalid","Enter a number for minutes.")

    # ── PAGE: ASSISTANT ───────────────────────────────────────────────────────

    def _page_assistant(self):
        pg=ctk.CTkFrame(self.content,fg_color="transparent"); self.pages["Assistant"]=pg
        hdr=ctk.CTkFrame(pg,fg_color="transparent"); hdr.pack(fill="x",pady=(0,4))
        ctk.CTkLabel(hdr,text="🤖  AI Assistant",font=("Segoe UI",22,"bold"),
                     text_color=TEXT).pack(side="left")
        self.ai_mode_lbl=ctk.CTkLabel(hdr,text="● Smart Mode",
                                       font=("Segoe UI",11),text_color=GREEN)
        self.ai_mode_lbl.pack(side="right")
        ctk.CTkLabel(pg,text="Ask about attendance, analytics, or give app commands",
                     font=("Segoe UI",12),text_color=MUTED).pack(anchor="w",pady=(0,10))
        self.chat_scroll=ctk.CTkScrollableFrame(pg,fg_color=SURFACE,corner_radius=12)
        self.chat_scroll.pack(fill="both",expand=True,pady=(0,10))
        pills=ctk.CTkFrame(pg,fg_color="transparent"); pills.pack(fill="x",pady=(0,8))
        for s in ["Who came today?","Who is absent?","Low attendance?",
                  "Start attendance","Open analytics","Open schedule"]:
            ctk.CTkButton(pills,text=s,font=("Segoe UI",11),height=28,
                          fg_color=SURF2,text_color=MUTED,hover_color=BORDER,
                          corner_radius=20,command=lambda x=s:self._send_msg(x)
                          ).pack(side="left",padx=3)
        inp=ctk.CTkFrame(pg,fg_color="transparent"); inp.pack(fill="x")
        self.chat_input=ctk.CTkEntry(inp,
            placeholder_text="Ask me anything...",
            height=44,font=("Segoe UI",13),fg_color=SURFACE,border_color=BORDER)
        self.chat_input.pack(side="left",fill="x",expand=True,padx=(0,8))
        self.chat_input.bind("<Return>",lambda e:self._on_send())
        self.send_btn=ctk.CTkButton(inp,text="Send ↗",width=90,height=44,
                                     font=("Segoe UI",13,"bold"),fg_color=PURPLE,
                                     corner_radius=8,command=self._on_send)
        self.send_btn.pack(side="right")
        self.after(400,self._show_welcome)

    def _assistant_on_open(self):
        self.ai_mode_lbl.configure(
            text="● Ollama AI" if self._chat_mode=="ollama" else "● Smart Mode",
            text_color=BLUE if self._chat_mode=="ollama" else GREEN)

    def _show_welcome(self):
        stats=self.analytics.student_stats()
        mode="Ollama llama3" if self._chat_mode=="ollama" else "Smart Built-in"
        self._add_bot_bubble(
            f"👋 Hi! I'm your AI assistant ({mode}).\n\n"
            f"I now know about your Analytics and Schedule too!\n\n"
            f"Try: 'Who has low attendance?' or 'Open schedule'")

    def _on_send(self):
        msg=self.chat_input.get().strip()
        if not msg: return
        self.chat_input.delete(0,"end"); self._send_msg(msg)

    def _send_msg(self,msg):
        self._add_user_bubble(msg)
        self.send_btn.configure(state="disabled",text="...")
        threading.Thread(target=self._get_response,args=(msg,),daemon=True).start()

    def _get_response(self,msg):
        try:
            if self._chat_mode=="ollama" and self.ollama_bot:
                reply=self.ollama_bot.chat(msg)
            else:
                reply=self.smart_bot.respond(msg)
        except Exception as e:
            reply=f"⚠ Error: {e}"; self._chat_mode="smart"
        self.after(0,self._add_bot_bubble,reply)
        self.after(0,self.send_btn.configure,{"state":"normal","text":"Send ↗"})

    def _add_user_bubble(self,text):
        row=ctk.CTkFrame(self.chat_scroll,fg_color="transparent"); row.pack(fill="x",pady=4,padx=4)
        b=ctk.CTkFrame(row,fg_color=ACCENT,corner_radius=12); b.pack(side="right",padx=(80,0))
        ctk.CTkLabel(b,text=text,font=("Segoe UI",13),text_color="white",
                     wraplength=380,justify="left").pack(padx=14,pady=10)
        self._scroll_bottom()

    def _add_bot_bubble(self,text):
        row=ctk.CTkFrame(self.chat_scroll,fg_color="transparent"); row.pack(fill="x",pady=4,padx=4)
        ctk.CTkLabel(row,text="🤖",font=("Segoe UI Emoji",20),width=36).pack(
            side="left",anchor="n",padx=(0,6),pady=4)
        b=ctk.CTkFrame(row,fg_color=SURF2,corner_radius=12); b.pack(side="left",padx=(0,80))
        ctk.CTkLabel(b,text=text,font=("Segoe UI",13),text_color=TEXT,
                     wraplength=480,justify="left").pack(padx=14,pady=10)
        ctk.CTkLabel(row,text=datetime.now().strftime("%H:%M"),
                     font=("Segoe UI",10),text_color=MUTED).pack(side="left",anchor="s",pady=4)
        self._scroll_bottom()

    def _scroll_bottom(self):
        self.after(50,lambda:self.chat_scroll._parent_canvas.yview_moveto(1.0))

    # ── WEB DASHBOARD ─────────────────────────────────────────────────────────

    def _open_web(self):
        dash=p("dashboard.py")
        if not os.path.exists(dash):
            messagebox.showinfo("Not Found","dashboard.py not found."); return
        if self.dashboard_proc and self.dashboard_proc.poll() is None:
            webbrowser.open("http://localhost:5000"); return
        try:
            flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
            self.dashboard_proc=subprocess.Popen([sys.executable,dash],creationflags=flags)
            self.after(1500,lambda:webbrowser.open("http://localhost:5000"))
        except Exception as e: messagebox.showerror("Error",str(e))

    # ── CLOSE ─────────────────────────────────────────────────────────────────

    def on_close(self):
        self.camera_running=False
        if self.cap: self.cap.release()
        if self.dashboard_proc and self.dashboard_proc.poll() is None:
            self.dashboard_proc.terminate()
        cv2.destroyAllWindows(); self.destroy()


if __name__=="__main__":
    app=App()
    app.protocol("WM_DELETE_WINDOW",app.on_close)
    app.mainloop()
