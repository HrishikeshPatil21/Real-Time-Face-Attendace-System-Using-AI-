"""
dashboard.py — Web Dashboard for Face Attendance System
=========================================================
Run:  python dashboard.py
Then open:  http://localhost:5000

Features:
  - View today's and past attendance records
  - Search / filter students
  - Download CSV
  - Attendance percentage per student
  - Clean dark UI — no external CSS framework needed
"""

from flask import Flask, render_template_string, jsonify, send_file, request
import os, csv, glob
from datetime import datetime
from collections import defaultdict

app = Flask(__name__)
ATTENDANCE_DIR = "Attendance"

HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Face Attendance Dashboard</title>
<style>
  :root {
    --bg:      #0d1117;
    --surface: #161b22;
    --border:  #30363d;
    --text:    #e6edf3;
    --muted:   #8b949e;
    --green:   #3fb950;
    --red:     #f85149;
    --blue:    #58a6ff;
    --yellow:  #e3b341;
    --accent:  #1f6feb;
  }
  * { box-sizing:border-box; margin:0; padding:0; }
  body { background:var(--bg); color:var(--text); font-family:'Segoe UI',system-ui,sans-serif; font-size:14px; }

  /* Layout */
  .topbar { background:var(--surface); border-bottom:1px solid var(--border);
            padding:14px 28px; display:flex; align-items:center; gap:16px; }
  .topbar h1 { font-size:17px; font-weight:600; }
  .topbar .badge { background:var(--accent); color:#fff; font-size:11px;
                   padding:2px 9px; border-radius:20px; font-weight:500; }
  .topbar .live { margin-left:auto; display:flex; align-items:center; gap:6px;
                  color:var(--green); font-size:12px; }
  .dot { width:8px; height:8px; border-radius:50%; background:var(--green);
         animation:pulse 1.8s infinite; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }

  .main { padding:24px 28px; max-width:1200px; margin:0 auto; }

  /* Stats row */
  .stats { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:24px; }
  .stat { background:var(--surface); border:1px solid var(--border); border-radius:10px;
          padding:16px 20px; }
  .stat .val { font-size:28px; font-weight:700; }
  .stat .lbl { color:var(--muted); font-size:12px; margin-top:4px; }
  .stat.green .val { color:var(--green); }
  .stat.blue  .val { color:var(--blue); }
  .stat.yellow .val { color:var(--yellow); }

  /* Toolbar */
  .toolbar { display:flex; gap:10px; align-items:center; margin-bottom:16px; flex-wrap:wrap; }
  .toolbar input, .toolbar select {
    background:var(--surface); border:1px solid var(--border); color:var(--text);
    border-radius:6px; padding:7px 12px; font-size:13px; outline:none;
  }
  .toolbar input:focus, .toolbar select:focus { border-color:var(--blue); }
  .toolbar input { flex:1; min-width:200px; }
  .btn { background:var(--accent); color:#fff; border:none; border-radius:6px;
         padding:7px 16px; cursor:pointer; font-size:13px; font-weight:500;
         transition:opacity .15s; text-decoration:none; }
  .btn:hover { opacity:.85; }
  .btn.outline { background:transparent; border:1px solid var(--border); color:var(--text); }
  .btn.outline:hover { background:var(--surface); }

  /* Table */
  .table-wrap { background:var(--surface); border:1px solid var(--border);
                border-radius:10px; overflow:hidden; }
  table { width:100%; border-collapse:collapse; }
  thead { background:#1c2128; }
  th { padding:11px 16px; text-align:left; color:var(--muted); font-size:12px;
       font-weight:500; letter-spacing:.05em; text-transform:uppercase;
       border-bottom:1px solid var(--border); }
  td { padding:11px 16px; border-bottom:1px solid var(--border); }
  tr:last-child td { border-bottom:none; }
  tbody tr:hover { background:rgba(255,255,255,.03); }

  .pill { display:inline-flex; align-items:center; gap:5px; font-size:12px;
          padding:2px 10px; border-radius:20px; font-weight:500; }
  .pill.present { background:rgba(63,185,80,.15); color:var(--green); }
  .pill.unknown { background:rgba(248,81,73,.15); color:var(--red); }
  .pill.pct { background:rgba(88,166,255,.12); color:var(--blue); }

  .avatar { width:30px; height:30px; border-radius:50%; background:var(--accent);
             display:inline-flex; align-items:center; justify-content:center;
             font-size:12px; font-weight:700; color:#fff; margin-right:8px; }

  /* Date tabs */
  .date-tabs { display:flex; gap:6px; margin-bottom:16px; flex-wrap:wrap; }
  .date-tab { background:var(--surface); border:1px solid var(--border);
              border-radius:6px; padding:5px 14px; font-size:12px; cursor:pointer;
              color:var(--muted); transition:all .15s; }
  .date-tab:hover, .date-tab.active { background:var(--accent); color:#fff;
                                       border-color:var(--accent); }

  .empty { text-align:center; padding:48px; color:var(--muted); }
  .empty .icon { font-size:40px; margin-bottom:12px; }

  footer { text-align:center; padding:24px; color:var(--muted); font-size:12px; }
</style>
</head>
<body>

<div class="topbar">
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#58a6ff" stroke-width="2">
    <circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
  </svg>
  <h1>Face Attendance Dashboard</h1>
  <span class="badge">Beta</span>
  <div class="live"><div class="dot"></div> Live</div>
</div>

<div class="main">

  <!-- Stats -->
  <div class="stats" id="stats">
    <div class="stat green">
      <div class="val" id="stat-today">—</div>
      <div class="lbl">Present today</div>
    </div>
    <div class="stat blue">
      <div class="val" id="stat-total">—</div>
      <div class="lbl">Total sessions</div>
    </div>
    <div class="stat yellow">
      <div class="val" id="stat-students">—</div>
      <div class="lbl">Unique students</div>
    </div>
    <div class="stat">
      <div class="val" id="stat-rate" style="color:var(--text)">—</div>
      <div class="lbl">Today's time</div>
    </div>
  </div>

  <!-- Date tabs -->
  <div class="date-tabs" id="date-tabs"></div>

  <!-- Toolbar -->
  <div class="toolbar">
    <input type="text" id="search" placeholder="Search by name or ID..." oninput="filterTable()">
    <select id="sort-select" onchange="filterTable()">
      <option value="time">Sort by Time</option>
      <option value="name">Sort by Name</option>
      <option value="id">Sort by ID</option>
    </select>
    <a class="btn" id="dl-btn" href="#">⬇ Download CSV</a>
    <button class="btn outline" onclick="loadData()">↻ Refresh</button>
  </div>

  <!-- Table -->
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Student</th>
          <th>ID</th>
          <th>Date</th>
          <th>Time</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody id="tbody"></tbody>
    </table>
  </div>

  <footer>Face Attendance System &nbsp;·&nbsp; Auto-refreshes every 15s</footer>
</div>

<script>
let allData = [];
let currentFile = '';
let allFiles = [];

async function loadFiles() {
  const r = await fetch('/api/files');
  allFiles = await r.json();
  const tabs = document.getElementById('date-tabs');
  tabs.innerHTML = '';
  allFiles.forEach((f, i) => {
    const btn = document.createElement('div');
    btn.className = 'date-tab' + (i===0 ? ' active' : '');
    btn.textContent = f.label;
    btn.onclick = () => {
      document.querySelectorAll('.date-tab').forEach(t => t.classList.remove('active'));
      btn.classList.add('active');
      loadData(f.filename);
    };
    tabs.appendChild(btn);
  });
  if (allFiles.length) loadData(allFiles[0].filename);
  else renderEmpty();
}

async function loadData(filename) {
  if (!filename && allFiles.length) filename = allFiles[0].filename;
  if (!filename) return;
  currentFile = filename;
  document.getElementById('dl-btn').href = '/download/' + filename;
  const r = await fetch('/api/attendance/' + filename);
  allData = await r.json();
  updateStats();
  filterTable();
}

function updateStats() {
  const today = new Date().toISOString().slice(0,10);
  const todayRows = allData.filter(r => r.date === today);
  const unique = [...new Set(allData.map(r => r.id))];
  document.getElementById('stat-today').textContent = todayRows.length;
  document.getElementById('stat-total').textContent = allData.length;
  document.getElementById('stat-students').textContent = unique.length;
  document.getElementById('stat-rate').textContent = new Date().toLocaleTimeString();
}

function filterTable() {
  const q = document.getElementById('search').value.toLowerCase();
  const sort = document.getElementById('sort-select').value;
  let rows = allData.filter(r =>
    r.name.toLowerCase().includes(q) || String(r.id).includes(q));
  if (sort === 'name') rows.sort((a,b) => a.name.localeCompare(b.name));
  else if (sort === 'id') rows.sort((a,b) => a.id - b.id);
  renderTable(rows);
}

function renderTable(rows) {
  const tbody = document.getElementById('tbody');
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty"><div class="icon">📭</div>No records found</div></td></tr>';
    return;
  }
  tbody.innerHTML = rows.map((r, i) => {
    const initials = r.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
    return `<tr>
      <td style="color:var(--muted)">${i+1}</td>
      <td><span class="avatar">${initials}</span>${r.name}</td>
      <td style="color:var(--muted);font-family:monospace">${r.id}</td>
      <td>${r.date}</td>
      <td style="font-family:monospace">${r.time}</td>
      <td><span class="pill present">✓ Present</span></td>
    </tr>`;
  }).join('');
}

function renderEmpty() {
  document.getElementById('tbody').innerHTML =
    '<tr><td colspan="6"><div class="empty"><div class="icon">📂</div>No attendance files found.<br>Run attendance.py to start marking.</div></td></tr>';
}

loadFiles();
setInterval(loadFiles, 15000);  // auto-refresh every 15s
</script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML)


@app.route('/api/files')
def api_files():
    files = sorted(glob.glob(os.path.join(ATTENDANCE_DIR, "*.csv")), reverse=True)
    result = []
    for f in files:
        fname = os.path.basename(f)
        try:
            date_part = fname.replace("Attendance_","").replace(".csv","")
            dt = datetime.strptime(date_part, "%Y-%m-%d")
            label = dt.strftime("%d %b %Y")
            if date_part == datetime.now().strftime("%Y-%m-%d"):
                label = "Today — " + label
        except ValueError:
            label = fname
        result.append({"filename": fname, "label": label})
    return jsonify(result)


@app.route('/api/attendance/<filename>')
def api_attendance(filename):
    path = os.path.join(ATTENDANCE_DIR, filename)
    if not os.path.exists(path):
        return jsonify([])
    rows = []
    with open(path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append({
                "id":   row.get("ID",""),
                "name": row.get("Name",""),
                "date": row.get("Date",""),
                "time": row.get("Time",""),
            })
    return jsonify(rows)


@app.route('/download/<filename>')
def download(filename):
    path = os.path.join(ATTENDANCE_DIR, filename)
    if os.path.exists(path):
        return send_file(path, as_attachment=True)
    return "File not found", 404


if __name__ == '__main__':
    print("[INFO] Dashboard running at http://localhost:5000")
    app.run(debug=False, port=5000)
